package control;

import java.net.URL;
import java.util.ResourceBundle;

import org.omg.Messaging.SyncScopeHelper;

import com.jfoenix.controls.JFXButton;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.shape.Circle;
import model.Paciente;

public class ControladorDrawer implements Initializable {

	@FXML
    private JFXButton b1;
    @FXML
    private JFXButton b2;
    @FXML
    private JFXButton b3;
    @FXML
    private JFXButton b4;
    @FXML
    private JFXButton b5;
    
    private ControladorMainTest cMainTest; 
    
    public ControladorDrawer(ControladorMainTest cmt) {
    	cMainTest = cmt;
    }
    
    public void initialize(URL url, ResourceBundle rb) {
    	if(ControladorLogin.usuarioActivo.tipo == 's') {
    		b1.setText("Tabla de Pacientes");
    		b2.setText("Notificaciones");
    		b3.setText("Chat");
    		b4.setText("Perfil");
    		b5.setText("Gestión");
    		cMainTest.pacientes.setVisible(true);
        	cMainTest.ctp.cargarTablaPacientes();
    	} else {
    		b1.setText("Bienvenida");
    		b2.setText("Pulsometro");
    		b3.setText("Chat");
    		b4.setText("Perfil");
    		b5.setText("Alertas");
    		cMainTest.inicio.setVisible(true);
    	}
    }

    @FXML
    private void exit(ActionEvent event) {
        System.exit(0);
    }
    
    @FXML
    private void startb1(ActionEvent event) {
    	if(ControladorLogin.usuarioActivo.tipo == 's') {
        	cMainTest.pacientes.setVisible(true);
        	cMainTest.notificaciones.setVisible(false);
        	cMainTest.perfil.setVisible(false);
        	cMainTest.chat.setVisible(false);
        	cMainTest.pulsometro.setVisible(false);
        	cMainTest.alertas.setVisible(false);
        	cMainTest.gestion.setVisible(false);
        	cMainTest.menuGestion.setVisible(false);
        	cMainTest.registro.setVisible(false);
        	cMainTest.asociar.setVisible(false);
        	cMainTest.ctp.cargarTablaPacientes();
    	} else {
	        cMainTest.inicio.setVisible(true);
	        cMainTest.perfil.setVisible(false);
	        cMainTest.chat.setVisible(false);
	    	cMainTest.pulsometro.setVisible(false);
	    	cMainTest.alertas.setVisible(false);
    	}
    }
    
    @FXML
    private void startb2(ActionEvent event) {
    	if(ControladorLogin.usuarioActivo.tipo == 's') {
        	cMainTest.pacientes.setVisible(false);
        	cMainTest.notificaciones.setVisible(true);
        	cMainTest.chat.setVisible(false);
        	cMainTest.perfil.setVisible(false);
        	cMainTest.pulsometro.setVisible(false);
        	cMainTest.alertas.setVisible(false);
        	cMainTest.gestion.setVisible(false);
        	cMainTest.menuGestion.setVisible(false);
        	cMainTest.registro.setVisible(false);
        	cMainTest.asociar.setVisible(false);
    		cMainTest.cn.cargarNotificaciones();
    	} else {
    		cMainTest.inicio.setVisible(false);
	        cMainTest.perfil.setVisible(false);
	        cMainTest.chat.setVisible(false);
	    	cMainTest.pulsometro.setVisible(true);
	    	cMainTest.alertas.setVisible(false);
	    	cMainTest.cg.cargarPulsometro((Paciente)ControladorLogin.usuarioActivo);
    	}
    }
    
    @FXML
    private void startb3(ActionEvent event) {
    	if(ControladorLogin.usuarioActivo.tipo == 's') {
    		cMainTest.pacientes.setVisible(false);
        	cMainTest.notificaciones.setVisible(false);
        	cMainTest.chat.setVisible(true);    	
        	cMainTest.perfil.setVisible(false);
        	cMainTest.pulsometro.setVisible(false);
        	cMainTest.alertas.setVisible(false);
        	cMainTest.gestion.setVisible(false);
        	cMainTest.menuGestion.setVisible(false);
        	cMainTest.registro.setVisible(false);
        	cMainTest.asociar.setVisible(false);
    	} else {
    		cMainTest.inicio.setVisible(false);
	        cMainTest.perfil.setVisible(false);
	        cMainTest.chat.setVisible(true);
	    	cMainTest.pulsometro.setVisible(false);
	    	cMainTest.alertas.setVisible(false);
    	}
		cMainTest.cc.cargarDatosChat();
    }
    
    @FXML
    private void startb4(ActionEvent event) {
    	if(ControladorLogin.usuarioActivo.tipo == 's') {
    		cMainTest.pacientes.setVisible(false);
        	cMainTest.notificaciones.setVisible(false);
        	cMainTest.chat.setVisible(false); 
        	cMainTest.perfil.setVisible(true);
        	cMainTest.pulsometro.setVisible(false);
        	cMainTest.alertas.setVisible(false);
        	cMainTest.gestion.setVisible(false);
        	cMainTest.menuGestion.setVisible(false);
        	cMainTest.registro.setVisible(false);
        	cMainTest.asociar.setVisible(false);
        	
    	} else {
    		cMainTest.inicio.setVisible(false);
	        cMainTest.perfil.setVisible(true);
	        cMainTest.chat.setVisible(false);
	    	cMainTest.pulsometro.setVisible(false);
	    	cMainTest.alertas.setVisible(false);
    	}
    	cMainTest.cpu.cargarPerfilUsuario(ControladorLogin.usuarioActivo);
    }
    
    @FXML
    private void startb5(ActionEvent event) {
    	if(ControladorLogin.usuarioActivo.tipo == 's') {
    		cMainTest.pacientes.setVisible(false);
        	cMainTest.notificaciones.setVisible(false);
        	cMainTest.chat.setVisible(false); 
        	cMainTest.perfil.setVisible(false);
        	cMainTest.gestion.setVisible(true);
        	cMainTest.menuGestion.setVisible(true);
        	cMainTest.registro.setVisible(false);
        	cMainTest.asociar.setVisible(false);
    	} else {
    		cMainTest.inicio.setVisible(false);
	        cMainTest.perfil.setVisible(false);
	        cMainTest.chat.setVisible(false);
	    	cMainTest.pulsometro.setVisible(false);
	    	cMainTest.alertas.setVisible(true);
	    	
	    	cMainTest.cta.cargarHistorialAlertas((Paciente)ControladorLogin.usuarioActivo);
    	}
    }

}

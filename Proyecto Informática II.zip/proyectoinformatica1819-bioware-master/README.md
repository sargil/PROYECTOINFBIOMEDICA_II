# baseMVC
Ejemplo Base del Modelo-Vista-Controlador en Java

Puedes utilizar este código como base de la aplicación que vas a desarrollar.